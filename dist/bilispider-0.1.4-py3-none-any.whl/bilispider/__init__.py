#from __future__ import absolute_import

def main():
    from .start import start
    start()
version = '0.1.4'
name = 'bilispider'

from .bilispider import *
