#from __future__ import absolute_import
__all__ = ['start']
def main():
    from .start import start
    start()
version = '0.1.2'
name = 'BiliSpider'

from BiliSpider.BiliSpider import *
