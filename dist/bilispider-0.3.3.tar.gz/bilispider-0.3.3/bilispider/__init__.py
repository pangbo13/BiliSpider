#from __future__ import absolute_import

def main():
    from .start import start
    start()

from .version import version
name = 'bilispider'

from .bilispider import *
