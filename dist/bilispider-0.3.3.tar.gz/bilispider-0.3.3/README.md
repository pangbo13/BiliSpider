
A spider of BiliBili.

基于python3编写的一个bilibili多线程爬虫。

# 安装

## 安装python 3.7 
> https://www.python.org/downloads/
## 安装bilispider
> pip3 install bilispider
## 使用
### Windows
> 在cmd中使用bilispider启动，输入bilispider –help以查看帮助
>
> 在cmd中使用python -m bilispider
## Linux
> 在终端中使用python3 -m bilispider 启动
## 以模块导入
> import bilispider
>
> 使用help(bilispider.bilispider)以查看用法
>
> 实例化类：s = bilispider.spider(tid,config={})
